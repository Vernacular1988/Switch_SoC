// (C) 2010 Fraunhofer Institut Integrierte Schaltungen - EAS Dresden
// Author            : Karsten Einwich
// Email             : karsten.einwich@eas.iis.fraunhofer.de
// Created on        : Jan 14, 2010
//
// comb_filter.cpp
//
// SVN Version       :  $Revision$
// SVN last checkin  :  $Date: 2010-01-14 22:06:01 +0100 (Do, 14 Jan 2010) $
// SVN checkin by    :  $Author: karsten $
// SVN Id            :  $Id: comb_filter.cpp 899 2010-01-14 21:06:01Z karsten $
//

#include <systemc-ams.h>
#include "comb_filter.h"

??????
